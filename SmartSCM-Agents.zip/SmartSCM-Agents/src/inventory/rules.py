# src/inventory/rules.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import pandas as pd


@dataclass
class InventoryPlan:
    """单一品项的库存决策结果。"""
    item_id: str
    risk_level: str
    reorder_qty: int
    projected_remaining: float
    lead_time_days: int
    safety_stock: int
    current_inventory: int


class InventoryPlanner:
    def __init__(self, inventory_path: Path | str = "data/processed/inventory.csv"):
        """
        读取事先准备好的库存表：
        - item_id
        - current_inventory
        - safety_stock
        - lead_time_days
        - store_id
        """
        self.inventory_path = Path(inventory_path)
        self.inv = pd.read_csv(self.inventory_path)

    def compute_inventory_plan(self, item_id: str, forecast: list[float]) -> InventoryPlan:
        """
        根据预测需求 + 库存设定，计算：
        - 缺货风险等级
        - 建议补货量
        - 预期剩余库存

        forecast: 未来 N 天的预测需求 list（例如 horizon=14）
        """

        row = self.inv[self.inv["item_id"] == item_id]
        if row.empty:
            raise ValueError(f"Item {item_id} not found in inventory table.")

        row = row.iloc[0]

        current_inv = int(row["current_inventory"])
        safety_stock = int(row["safety_stock"])
        lead_time = int(row["lead_time_days"])

        # lead time 期间的总预测需求
        demand_lt = sum(forecast[:lead_time])

        # 预期在 lead time 结束时剩余的库存
        projected_remaining = current_inv - demand_lt

        # 风险等级（门槛可以之后再调整）
        if projected_remaining >= safety_stock:
            risk = "LOW"
        elif projected_remaining >= 0:
            risk = "MEDIUM"
        else:
            risk = "HIGH"

        # 建议补货量：目标库存 = safety_stock + demand_lt
        target_level = safety_stock + demand_lt
        reorder_qty = max(0, int(round(target_level - current_inv)))

        return InventoryPlan(
            item_id=item_id,
            risk_level=risk,
            reorder_qty=reorder_qty,
            projected_remaining=float(projected_remaining),
            lead_time_days=lead_time,
            safety_stock=safety_stock,
            current_inventory=current_inv,
        )
