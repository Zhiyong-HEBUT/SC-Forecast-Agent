# src/forecasting/train_baseline.py
from __future__ import annotations
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

from src.forecasting.features import build_feature_table

PROCESSED_DIR = Path("data/processed")
MODELS_DIR = Path("models")


def load_daily_sales() -> pd.DataFrame:
    return pd.read_csv(
        PROCESSED_DIR / "daily_sales.csv",
        parse_dates=["date"],
        low_memory=False,
    )


def select_subset(df: pd.DataFrame, store_id: str = "CA_1") -> pd.DataFrame:
    """Train the baseline model on one store."""
    return df[df["store_id"] == store_id].copy()


def train_val_test_split(
    df: pd.DataFrame,
    val_days: int = 28,
    test_days: int = 28,
):
    """Time-based train/validation/test split."""
    df = df.sort_values("date")
    max_date = df["date"].max()

    test_start = max_date - pd.Timedelta(days=test_days - 1)
    val_start = test_start - pd.Timedelta(days=val_days)

    train = df[df["date"] < val_start]
    val = df[(df["date"] >= val_start) & (df["date"] < test_start)]
    test = df[df["date"] >= test_start]

    return train, val, test


def get_feature_target(df: pd.DataFrame):
    """Select the features used by the baseline model."""
    feature_cols = [
        "dow",
        "weekofyear",
        "month",
        "year",
        "sell_price",
        "lag_7",
        "lag_14",
        "rollmean_7",
        "rollmean_28",
    ]
    return df[feature_cols], df["sales_qty"]


def safe_wmape(y_true, y_pred) -> float:
    """Weighted MAPE; stable when individual actual observations are zero."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.abs(y_true).sum()
    if denom <= 1e-12:
        return float("nan")
    return float(np.abs(y_true - y_pred).sum() / denom)


def safe_smape(y_true, y_pred) -> float:
    """Symmetric MAPE with zero/zero terms defined as zero."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.abs(y_true) + np.abs(y_pred)
    numer = 2.0 * np.abs(y_pred - y_true)

    terms = np.divide(
        numer,
        denom,
        out=np.zeros_like(numer, dtype=float),
        where=denom > 1e-12,
    )
    return float(np.mean(terms))


def forecast_bias_pct(y_true, y_pred) -> float:
    """Signed aggregate forecast bias divided by total actual demand."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.abs(y_true).sum()
    if denom <= 1e-12:
        return float("nan")
    return float((y_pred - y_true).sum() / denom)


def train_baseline_model():
    df = select_subset(load_daily_sales())
    df_feat = build_feature_table(df)

    train, val, test = train_val_test_split(df_feat)
    X_train, y_train = get_feature_target(train)
    X_val, y_val = get_feature_target(val)
    X_test, y_test = get_feature_target(test)

    model = LGBMRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=-1,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
    )

    model.fit(
        X_train,
        y_train,
        eval_set=[(X_val, y_val)],
        eval_metric="rmse",
    )

    def eval_and_print(split_name, X, y):
        # Production demand is clipped at zero, so evaluate the same behavior.
        preds = np.clip(model.predict(X), a_min=0.0, a_max=None)

        rmse = mean_squared_error(y, preds) ** 0.5
        mae = mean_absolute_error(y, preds)
        wmape = safe_wmape(y, preds)
        smape = safe_smape(y, preds)
        bias = forecast_bias_pct(y, preds)

        print(
            f"{split_name} - "
            f"RMSE: {rmse:.3f}, "
            f"MAE: {mae:.3f}, "
            f"WMAPE: {wmape:.3%}, "
            f"sMAPE: {smape:.3%}, "
            f"Bias: {bias:.3%}"
        )

    eval_and_print("Train", X_train, y_train)
    eval_and_print("Val", X_val, y_val)
    eval_and_print("Test", X_test, y_test)

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    model_path = MODELS_DIR / "baseline_lgbm_ca1.pkl"
    joblib.dump(model, model_path)
    print(f"Saved model to {model_path}")


if __name__ == "__main__":
    train_baseline_model()
