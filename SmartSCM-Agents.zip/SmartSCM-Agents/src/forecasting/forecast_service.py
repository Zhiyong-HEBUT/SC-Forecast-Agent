# src/forecasting/forecast_service.py
from __future__ import annotations

from pathlib import Path
from typing import List

import joblib
import numpy as np
import pandas as pd

PROCESSED_DIR = Path("data/processed")
MODELS_DIR = Path("models")


class DemandForecaster:
    """SKU-level recursive demand forecaster.

    The baseline model was trained with calendar, price, lag and rolling-mean
    features. For a multi-day forecast we therefore roll the series forward
    one day at a time and feed each prediction back into history so later
    lag/rolling features can change.
    """

    FEATURE_COLS = [
        "dow",
        "weekofyear",
        "month",
        "year",
        "sell_price",
        "lag_7",
        "lag_14",
        "rollmean_7",
        "rollmean_28",
    ]

    def __init__(self, model_path: Path, store_id: str = "CA_1"):
        self.model = joblib.load(model_path)
        self.store_id = store_id
        self.hist_df = pd.read_csv(
            PROCESSED_DIR / "daily_sales.csv",
            parse_dates=["date"],
            low_memory=False,
        )
        self.hist_df = self.hist_df[self.hist_df["store_id"] == store_id].copy()

    def forecast_demand(self, item_id: str, horizon_days: int = 14) -> List[float]:
        """Forecast horizon_days using recursive one-step-ahead prediction.

        Each predicted day is appended to the working demand history. This
        makes lag_7/lag_14 and rolling means evolve across the horizon instead
        of copying one prediction to every future day.
        """
        if horizon_days <= 0:
            raise ValueError("horizon_days must be a positive integer.")

        df_item = (
            self.hist_df[self.hist_df["item_id"] == item_id]
            .sort_values("date")
            .copy()
        )
        if df_item.empty:
            raise ValueError(
                f"Item {item_id!r} was not found for store {self.store_id!r}."
            )

        sales_history = df_item["sales_qty"].astype(float).tolist()
        if len(sales_history) < 28:
            raise ValueError(
                f"Item {item_id!r} needs at least 28 days of history; "
                f"found {len(sales_history)}."
            )

        # The baseline model needs a future price, but the demo has no future
        # price plan. Use the most recent known price as a transparent baseline
        # assumption. Replace this with a real future price table when available.
        known_prices = df_item["sell_price"].dropna()
        last_price = float(known_prices.iloc[-1]) if not known_prices.empty else 0.0

        last_date = pd.Timestamp(df_item["date"].max())
        preds: List[float] = []

        for step in range(1, horizon_days + 1):
            forecast_date = last_date + pd.Timedelta(days=step)
            row = self._build_future_feature_row(
                forecast_date=forecast_date,
                sell_price=last_price,
                sales_history=sales_history,
            )

            raw_pred = float(self.model.predict(row[self.FEATURE_COLS])[0])
            pred = max(raw_pred, 0.0)  # demand cannot be negative
            preds.append(pred)
            sales_history.append(pred)

        return preds

    def get_recent_average(self, item_id: str, window_days: int = 28) -> float:
        """Return recent actual average demand for forecast comparison."""
        if window_days <= 0:
            raise ValueError("window_days must be a positive integer.")

        df_item = (
            self.hist_df[self.hist_df["item_id"] == item_id]
            .sort_values("date")
            .tail(window_days)
        )
        if df_item.empty:
            raise ValueError(
                f"Item {item_id!r} was not found for store {self.store_id!r}."
            )
        return float(df_item["sales_qty"].astype(float).mean())

    def get_forecast_dates(self, item_id: str, horizon_days: int = 14) -> List[str]:
        """Return ISO dates matching the item-specific forecast horizon."""
        if horizon_days <= 0:
            raise ValueError("horizon_days must be a positive integer.")

        item_dates = self.hist_df.loc[self.hist_df["item_id"] == item_id, "date"]
        if item_dates.empty:
            raise ValueError(
                f"Item {item_id!r} was not found for store {self.store_id!r}."
            )

        last_date = pd.Timestamp(item_dates.max())
        return [
            (last_date + pd.Timedelta(days=step)).strftime("%Y-%m-%d")
            for step in range(1, horizon_days + 1)
        ]

    @staticmethod
    def _build_future_feature_row(
        forecast_date: pd.Timestamp,
        sell_price: float,
        sales_history: List[float],
    ) -> pd.DataFrame:
        """Build the exact feature vector used by the baseline LightGBM model."""
        if len(sales_history) < 28:
            raise ValueError(
                "At least 28 observations are required for rolling features."
            )

        iso = forecast_date.isocalendar()
        feature_values = {
            "dow": int(forecast_date.weekday()),
            "weekofyear": int(iso.week),
            "month": int(forecast_date.month),
            "year": int(forecast_date.year),
            "sell_price": float(sell_price),
            "lag_7": float(sales_history[-7]),
            "lag_14": float(sales_history[-14]),
            "rollmean_7": float(np.mean(sales_history[-7:])),
            "rollmean_28": float(np.mean(sales_history[-28:])),
        }
        return pd.DataFrame([feature_values])
