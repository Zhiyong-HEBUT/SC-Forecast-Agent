# src/forecasting/features.py
from __future__ import annotations
import pandas as pd


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    依据 date 栏位加入基本时间特征。
    需要 df['date'] 已经是 datetime64。
    """
    df = df.copy()
    df["dow"] = df["date"].dt.weekday
    df["weekofyear"] = df["date"].dt.isocalendar().week.astype(int)
    df["month"] = df["date"].dt.month
    df["year"] = df["date"].dt.year
    return df


def add_lag_features(df: pd.DataFrame,
                     group_cols=("store_id", "item_id"),
                     lag_days=(7, 14)) -> pd.DataFrame:
    """
    对每个 (store_id, item_id) 做 sales_qty 的 lag 特征。
    """
    df = df.sort_values(["store_id", "item_id", "date"]).copy()
    for lag in lag_days:
        df[f"lag_{lag}"] = (
            df.groupby(list(group_cols))["sales_qty"]
              .shift(lag)
        )
    return df


def add_rolling_features(df: pd.DataFrame,
                         group_cols=("store_id", "item_id"),
                         windows=(7, 28)) -> pd.DataFrame:
    """
    rolling mean / std 特征。
    """
    df = df.sort_values(["store_id", "item_id", "date"]).copy()
    for win in windows:
        grp = df.groupby(list(group_cols))["sales_qty"]
        df[f"rollmean_{win}"] = grp.shift(1).rolling(win).mean()
        df[f"rollstd_{win}"] = grp.shift(1).rolling(win).std()
    return df


def build_feature_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    串起来：时间特征 + lag + rolling。
    这个 df 就是你之后拿去丢进模型的训练资料。
    """
    df = add_time_features(df)
    df = add_lag_features(df)
    df = add_rolling_features(df)
    # 也可以顺便填掉一部分缺失值，或过滤前几天没有 lag 的列
    df = df.dropna(subset=[c for c in df.columns if c.startswith("lag_")])
    return df
