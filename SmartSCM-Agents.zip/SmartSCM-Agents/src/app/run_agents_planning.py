# src/app/run_agents_planning.py
from __future__ import annotations

import json
from argparse import ArgumentParser
from datetime import datetime

from src.agents.tools import PlanningTools
from src.agents.domain_agents import (
    build_demand_analyst_agent,
    build_inventory_planner_agent,
    build_report_agent,
)


def _fmt_pct(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.1f}%"


def _fmt_cv(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.3f}"


def main(date_str: str | None = None, top_n: int = 10):
    if date_str is None:
        date_str = datetime.today().strftime("%Y-%m-%d")

    tools = PlanningTools()
    items = tools.get_all_items()

    demand_agent = build_demand_analyst_agent()
    inv_agent = build_inventory_planner_agent()
    report_agent = build_report_agent()

    risk_rows: list[dict] = []
    for item_id in items:
        demand, plan = tools.analyze_item(item_id)

        risk_rows.append(
            {
                "item_id": item_id,
                "risk_level": plan.risk_level,
                "reorder_qty": plan.reorder_qty,
                "projected_remaining": plan.projected_remaining,
                "current_inventory": plan.current_inventory,
                "safety_stock": plan.safety_stock,
                "avg_daily_forecast": demand.avg_daily_forecast,
                "recent_avg_28": demand.recent_avg_28,
                "change_vs_recent_pct": demand.change_vs_recent_pct,
                "forecast_std": demand.forecast_std,
                "forecast_cv": demand.forecast_cv,
                "trend_pct": demand.trend_pct,
                "demand_level": demand.demand_level,
                "trend_direction": demand.trend_direction,
                "volatility_level": demand.volatility_level,
                "horizon_days": demand.horizon_days,
                "forecast_dates": demand.forecast_dates,
                "daily_forecast": demand.daily_forecast,
            }
        )

    risk_priority = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    risk_rows.sort(
        key=lambda r: (
            risk_priority[r["risk_level"]],
            r["projected_remaining"],
        )
    )
    top_rows = risk_rows[:top_n]

    enriched_rows: list[dict] = []
    for r in top_rows:
        item_id = r["item_id"]

        dated_forecast = [
            {"date": date, "forecast": round(value, 3)}
            for date, value in zip(
                r["forecast_dates"],
                r["daily_forecast"],
            )
        ]

        demand_msg = [
            {
                "role": "user",
                "content": (
                    f"品项 ID：{item_id}\n"
                    f"预测天数：{r['horizon_days']} 天\n"
                    f"逐日预测：{json.dumps(dated_forecast, ensure_ascii=False)}\n"
                    f"预测平均每日需求：{r['avg_daily_forecast']:.2f}\n"
                    f"最近 28 天实际平均每日需求：{r['recent_avg_28']:.2f}\n"
                    f"预测相对最近 28 天变化：{_fmt_pct(r['change_vs_recent_pct'])}\n"
                    f"系统需求层级：{r['demand_level']}\n"
                    f"预测期趋势：{r['trend_direction']}（前后半段变化 {_fmt_pct(r['trend_pct'])}）\n"
                    f"预测标准差：{r['forecast_std']:.2f}\n"
                    f"变异系数 CV：{_fmt_cv(r['forecast_cv'])}\n"
                    f"系统波动等级：{r['volatility_level']}"
                ),
            }
        ]
        demand_explanation = demand_agent.run(demand_msg)

        inv_msg = [
            {
                "role": "user",
                "content": (
                    f"品项 ID：{item_id}\n"
                    f"风险等级：{r['risk_level']}\n"
                    f"目前库存：{r['current_inventory']}\n"
                    f"安全库存：{r['safety_stock']}\n"
                    f"预期在补货前剩余库存：{r['projected_remaining']:.1f}\n"
                    f"建议补货量：{r['reorder_qty']}"
                ),
            }
        ]
        inv_explanation = inv_agent.run(inv_msg)

        enriched_rows.append(
            {
                **r,
                "demand_comment": demand_explanation,
                "inventory_comment": inv_explanation,
            }
        )

    report_input = {
        "date": date_str,
        "items": enriched_rows,
    }

    report_msg = [
        {
            "role": "user",
            "content": (
                "以下是一份今日高风险/中风险品项的分析结果（JSON 格式）：\n"
                + json.dumps(report_input, ensure_ascii=False, indent=2)
                + "\n\n请根据这些资料，产出一份给供应链主管看的中文报告。"
            ),
        }
    ]

    final_report = report_agent.run(report_msg)

    print("========== SmartSCM Agents Daily Report ==========")
    print(final_report)
    print("================================================")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument(
        "--date",
        type=str,
        default=None,
        help="Report date (for description only), format YYYY-MM-DD.",
    )
    parser.add_argument(
        "--top_n",
        type=int,
        default=10,
        help="Number of top risk items to analyze with agents.",
    )
    args = parser.parse_args()
    main(date_str=args.date, top_n=args.top_n)
