# src/app/dashboard.py
from __future__ import annotations

import sys
from pathlib import Path
from datetime import datetime

import pandas as pd
import streamlit as st

# 确保可以从专案根目录 import src.*
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.agents.tools import PlanningTools
from src.agents.domain_agents import (
    build_demand_analyst_agent,
    build_inventory_planner_agent,
    build_report_agent,
)


# ========= 资料计算相关 =========

def load_item_meta(processed_path: Path = Path("data/processed/daily_sales.csv")) -> pd.DataFrame:
    """
    从 daily_sales 抓出每个 item 的基本资讯：
    item_id, cat_id, dept_id, store_id
    用来在前端显示「品项描述」。
    """
    df = pd.read_csv(processed_path, low_memory=False)
    meta = (
        df.groupby("item_id")
        .agg(
            cat_id=("cat_id", "first"),
            dept_id=("dept_id", "first"),
            store_id=("store_id", "first"),
        )
        .reset_index()
    )
    # 简单组一个「看得懂」的描述（之后你可以改成手动 mapping 成品名）
    meta["item_desc"] = meta["cat_id"].astype(str) + " / " + meta["dept_id"].astype(str)
    return meta


def compute_risk_rows(tools: PlanningTools, meta_df: pd.DataFrame) -> pd.DataFrame:
    """
    跑一轮预测 + 库存规则，回传一个 DataFrame：
    每列就是一个品项的风险资讯 + 商品描述。
    """
    items = tools.get_all_items()
    rows: list[dict] = []

    for item_id in items:
        demand, plan = tools.analyze_item(item_id)

        rows.append(
            {
                "item_id": item_id,
                "risk_level": plan.risk_level,
                "reorder_qty": plan.reorder_qty,
                "projected_remaining": plan.projected_remaining,
                "current_inventory": plan.current_inventory,
                "safety_stock": plan.safety_stock,
                "avg_daily_forecast": demand.avg_daily_forecast,
                "recent_avg_28": demand.recent_avg_28,
                "change_vs_recent_pct": demand.change_vs_recent_pct,
                "forecast_std": demand.forecast_std,
                "forecast_cv": demand.forecast_cv,
                "trend_pct": demand.trend_pct,
                "demand_level": demand.demand_level,
                "trend_direction": demand.trend_direction,
                "volatility_level": demand.volatility_level,
                "horizon_days": demand.horizon_days,
                "forecast_dates": demand.forecast_dates,
                "daily_forecast": demand.daily_forecast,
            }
        )

    df = pd.DataFrame(rows)
    df = df.merge(meta_df[["item_id", "item_desc", "store_id"]], on="item_id", how="left")

    # 风险排序：HIGH > MEDIUM > LOW；同一级按 projected_remaining 由小到大
    risk_priority = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    df["risk_rank"] = df["risk_level"].map(risk_priority)
    df = df.sort_values(["risk_rank", "projected_remaining"])
    return df


def build_ai_report(date_str: str, top_rows: pd.DataFrame) -> str:
    """
    呼叫三个 Agents，产生一份中文报告。
    """
    import json

    demand_agent = build_demand_analyst_agent()
    inv_agent = build_inventory_planner_agent()
    report_agent = build_report_agent()

    enriched_rows: list[dict] = []

    for _, r in top_rows.iterrows():
        item_id = r["item_id"]

        dated_forecast = [
            {"date": date, "forecast": round(float(value), 3)}
            for date, value in zip(r["forecast_dates"], r["daily_forecast"])
        ]
        change_text = (
            "N/A"
            if pd.isna(r["change_vs_recent_pct"])
            else f"{float(r['change_vs_recent_pct']):.1f}%"
        )
        trend_text = (
            "N/A"
            if pd.isna(r["trend_pct"])
            else f"{float(r['trend_pct']):.1f}%"
        )
        cv_text = (
            "N/A"
            if pd.isna(r["forecast_cv"])
            else f"{float(r['forecast_cv']):.3f}"
        )

        demand_msg = [
            {
                "role": "user",
                "content": (
                    f"品项 ID：{item_id}\n"
                    f"品项描述：{r.get('item_desc', '')}\n"
                    f"预测天数：{int(r['horizon_days'])} 天\n"
                    f"逐日预测：{json.dumps(dated_forecast, ensure_ascii=False)}\n"
                    f"预测平均每日需求：{float(r['avg_daily_forecast']):.2f}\n"
                    f"最近 28 天实际平均每日需求：{float(r['recent_avg_28']):.2f}\n"
                    f"预测相对最近 28 天变化：{change_text}\n"
                    f"系统需求层级：{r['demand_level']}\n"
                    f"预测期趋势：{r['trend_direction']}（前后半段变化 {trend_text}）\n"
                    f"预测标准差：{float(r['forecast_std']):.2f}\n"
                    f"变异系数 CV：{cv_text}\n"
                    f"系统波动等级：{r['volatility_level']}"
                ),
            }
        ]
        demand_explanation = demand_agent.run(demand_msg)

        inv_msg = [
            {
                "role": "user",
                "content": (
                    f"品项 ID：{item_id}\n"
                    f"品项描述：{r.get('item_desc', '')}\n"
                    f"风险等级：{r['risk_level']}\n"
                    f"目前库存：{int(r['current_inventory'])}\n"
                    f"安全库存：{int(r['safety_stock'])}\n"
                    f"预期在补货前剩余库存：{r['projected_remaining']:.1f}\n"
                    f"建议补货量：{int(r['reorder_qty'])}"
                ),
            }
        ]
        inv_explanation = inv_agent.run(inv_msg)

        enriched_rows.append(
            {
                **r.to_dict(),
                "demand_comment": demand_explanation,
                "inventory_comment": inv_explanation,
            }
        )

    report_input = {
        "date": date_str,
        "items": enriched_rows,
    }

    report_msg = [
        {
            "role": "user",
            "content": (
                "以下是一份今日高风险/中风险品项的分析结果（JSON 格式）：\n"
                + json.dumps(report_input, ensure_ascii=False, indent=2)
                + "\n\n请根据这些资料，产出一份给供应链主管看的中文报告。"
            ),
        }
    ]

    final_report = report_agent.run(report_msg)
    return final_report


# ========= Streamlit UI =========

def main():
    st.set_page_config(
        page_title="SmartSCM Agents Dashboard",
        layout="wide",
    )

    # ---- Header ----
    st.markdown(
        """
        <h1 style="margin-bottom:0.2rem;">📦 SmartSCM Agents Dashboard</h1>
        <p style="color:#666;margin-top:0;">
        Demo：用需求预测 + 库存规则 + AI Agents，帮门市主管每天看哪些商品有缺货风险、该补多少货。
        </p>
        """,
        unsafe_allow_html=True,
    )

    # ---- Sidebar ----
    st.sidebar.header("⚙️ 报告设定")

    date = st.sidebar.date_input(
        "报告日期（可选择）",
        value=datetime.today(),
    )
    date_str = date.strftime("%Y-%m-%d")

    top_n = st.sidebar.slider("AI 报告要重点说明的品项数（Top N）", min_value=5, max_value=50, value=10, step=5)

    # ---- Data & Tools ----
    tools = PlanningTools()
    meta_df = load_item_meta()
    risk_df = compute_risk_rows(tools, meta_df)

    total_items = len(risk_df)
    high_risk = (risk_df["risk_level"] == "HIGH").sum()
    medium_risk = (risk_df["risk_level"] == "MEDIUM").sum()
    low_risk = (risk_df["risk_level"] == "LOW").sum()
    store_ids = sorted(risk_df["store_id"].dropna().unique())

    # ---- Summary Section ----
    st.subheader(f" 今日库存风险总览 - {date_str}")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("监控品项数量", int(total_items))
    col2.metric("高风险品项", int(high_risk))
    col3.metric("中风险品项", int(medium_risk))
    col4.metric("低风险品项", int(low_risk))

    store_text = "、".join(store_ids) if store_ids else "N/A"
    st.caption(
        f"目前 Demo 是以「{store_text}」这间门市为例，"
        f"大约监控 {total_items} 个商品。历史销量来自公开零售资料（可以想成一间大卖场的日销量纪录）。"
    )

    # ---- 可解释性：风险 + 指标说明 ----
    with st.expander("🧾 风险等级怎么算？（白话版本）", expanded=False):
        st.markdown(
            """
- **我们关心的时间窗**：先看「补货到货前」这几天（lead time）。
- **预期剩余库存** = 目前库存 −「lead time 期间的预测需求总和」。

在这个前提下：

- `HIGH`：预期剩余库存 **会掉到 0 以下** → 很可能会缺货  
- `MEDIUM`：预期剩余库存 **还大于 0，但已经低于安全库存** → 还不会立刻缺货，但偏危险  
- `LOW`：预期剩余库存 **高于安全库存** → 相对安全  
            """
        )

    with st.expander("🧮 表格里几个指标是怎么算的？", expanded=False):
        st.markdown(
            """
- **未来平均每日需求**：  
  - 用需求预测模型逐日滚动算出未来 14 天（可调整）的需求，每一天都会重新计算 lag / rolling 特征，再取平均。  
  - 直觉可以理解成：这个品项最近「大概一天会卖掉多少」。

- **预期剩余库存** `projected_remaining`：  
  - = 目前库存 −「补货到货前几天的预测需求总和」。  
  - 如果这个数字变成负的，代表照目前走势会「卖得比库存还多」，有缺货风险。

- **安全库存** `safety_stock`：  
  - 为了 Demo，我是用「最近一段时间的平均每日销量 × 3 天」来当作安全库存。  
  - 你可以把它想像成：就算需求稍微超标 2～3 天，还不会马上缺货的缓冲量。

- **建议补货量** `建议补货量`：  
  - 先把目标库存设在：「安全库存 + lead time 期间的预测需求」。  
  - 建议补货量 = 目标库存 − 目前库存（如果算出来是负的，就当 0）。  
  - 白话：补到「先把预测中的需求补满，再留一点安全缓冲」。
            """
        )

    st.markdown("---")

    # ---- 风险等级表格：用 Tabs 分开 ----
    st.subheader("🔥 各风险等级品项一览")

    tab_high, tab_medium, tab_low = st.tabs(["🔴 高风险", "🟠 中风险", "🟢 低风险"])

    def show_table(df: pd.DataFrame):
        if df.empty:
            st.info("目前没有此风险等级的品项。")
            return

        display = df[
            [
                "item_id",
                "item_desc",
                "risk_level",
                "reorder_qty",
                "projected_remaining",
                "current_inventory",
                "safety_stock",
                "avg_daily_forecast",
                "recent_avg_28",
                "demand_level",
                "trend_direction",
                "volatility_level",
            ]
        ].rename(
            columns={
                "item_id": "品项 ID",
                "item_desc": "品项描述",
                "risk_level": "风险等级",
                "reorder_qty": "建议补货量",
                "projected_remaining": "预期剩余库存",
                "current_inventory": "目前库存",
                "safety_stock": "安全库存",
                "avg_daily_forecast": "未来平均每日需求",
                "recent_avg_28": "最近28天平均需求",
                "demand_level": "需求层级",
                "trend_direction": "需求趋势",
                "volatility_level": "波动等级",
            }
        )

        st.dataframe(
            display,
            use_container_width=True,
            height=350,
        )

    with tab_high:
        show_table(risk_df[risk_df["risk_level"] == "HIGH"])

    with tab_medium:
        show_table(risk_df[risk_df["risk_level"] == "MEDIUM"])

    with tab_low:
        show_table(risk_df[risk_df["risk_level"] == "LOW"])

    # ---- AI Agents 报告（纯按钮，不再勾勾） ----
    st.markdown("---")
    st.subheader("🤖 AI Agents 产生的「主管报告」")

    st.caption(
        "系统会从所有品项中挑出风险最高的前 N 个，由需求分析 Agent + 库存规划 Agent 解释后，"
        "再交给报告 Agent 整理成一份给主管看的中文摘要。"
    )

    if st.button("产生今日 AI 报告"):
        with st.spinner("AI Agents 正在分析今日风险与补货建议..."):
            try:
                top_rows = risk_df.head(top_n)
                report_text = build_ai_report(date_str, top_rows)
                st.markdown(report_text)
            except Exception as e:
                st.error(f"产生 AI 报告时发生错误：{e}")
                st.info("请确认已设定 OPENAI_API_KEY，且模型名称与网路连线正常。")
    else:
        st.info("按下按钮，即可产生一份供应链主管阅读的中文报告。")


if __name__ == "__main__":
    main()
