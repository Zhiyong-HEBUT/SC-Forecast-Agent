# src/agents/tools.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import numpy as np

from src.forecasting.forecast_service import DemandForecaster
from src.inventory.rules import InventoryPlanner, InventoryPlan


@dataclass
class DemandInsight:
    """Structured demand metrics supplied to the Demand Analyst Agent."""

    item_id: str
    horizon_days: int
    forecast_dates: List[str]
    daily_forecast: List[float]
    avg_daily_forecast: float
    recent_avg_28: float
    change_vs_recent_pct: float | None
    forecast_std: float
    forecast_cv: float | None
    trend_pct: float | None
    demand_level: str
    trend_direction: str
    volatility_level: str


class PlanningTools:
    """Tools that combine demand forecasting and inventory planning."""

    def __init__(
        self,
        model_path: Path | str = Path("models/baseline_lgbm_ca1.pkl"),
        inventory_path: Path | str = Path("data/processed/inventory.csv"),
        store_id: str = "CA_1",
        default_horizon_days: int = 14,
    ):
        self.store_id = store_id
        self.default_horizon_days = default_horizon_days

        self.forecaster = DemandForecaster(Path(model_path), store_id=store_id)
        self.planner = InventoryPlanner(Path(inventory_path))

    def get_all_items(self) -> list[str]:
        """Return all item_ids in the current inventory table."""
        return list(self.planner.inv["item_id"].unique())

    def forecast_demand(
        self,
        item_id: str,
        horizon_days: int | None = None,
    ) -> DemandInsight:
        """Forecast demand and derive deterministic level/trend/volatility metrics."""
        if horizon_days is None:
            horizon_days = self.default_horizon_days

        forecast = self.forecaster.forecast_demand(
            item_id=item_id,
            horizon_days=horizon_days,
        )
        forecast_dates = self.forecaster.get_forecast_dates(item_id, horizon_days)

        arr = np.asarray(forecast, dtype=float)
        avg_daily = float(arr.mean())
        recent_avg_28 = self.forecaster.get_recent_average(item_id, window_days=28)
        forecast_std = float(arr.std(ddof=0))

        if recent_avg_28 > 1e-9:
            change_vs_recent_pct = float(
                (avg_daily - recent_avg_28) / recent_avg_28 * 100.0
            )
        elif avg_daily > 1e-9:
            # Percentage growth from a zero baseline is mathematically undefined.
            change_vs_recent_pct = None
        else:
            change_vs_recent_pct = 0.0

        forecast_cv = float(forecast_std / avg_daily) if avg_daily > 1e-9 else None

        # Compare the first and second halves to describe horizon direction.
        split_idx = max(1, len(arr) // 2)
        first_half = float(arr[:split_idx].mean())
        second_half = (
            float(arr[split_idx:].mean()) if split_idx < len(arr) else first_half
        )

        if first_half > 1e-9:
            trend_pct = float((second_half - first_half) / first_half * 100.0)
        elif second_half > 1e-9:
            trend_pct = None
        else:
            trend_pct = 0.0

        demand_level = self._classify_demand_level(
            avg_daily=avg_daily,
            recent_avg=recent_avg_28,
            change_pct=change_vs_recent_pct,
        )
        trend_direction = self._classify_trend(
            first_half, second_half, trend_pct
        )
        volatility_level = self._classify_volatility(forecast_cv)

        return DemandInsight(
            item_id=item_id,
            horizon_days=horizon_days,
            forecast_dates=forecast_dates,
            daily_forecast=[float(x) for x in arr],
            avg_daily_forecast=avg_daily,
            recent_avg_28=recent_avg_28,
            change_vs_recent_pct=change_vs_recent_pct,
            forecast_std=forecast_std,
            forecast_cv=forecast_cv,
            trend_pct=trend_pct,
            demand_level=demand_level,
            trend_direction=trend_direction,
            volatility_level=volatility_level,
        )

    @staticmethod
    def _classify_demand_level(
        avg_daily: float,
        recent_avg: float,
        change_pct: float | None,
    ) -> str:
        """Classify forecast level against the recent 28-day actual baseline."""
        if recent_avg <= 1e-9:
            return "HIGH" if avg_daily > 1e-9 else "NORMAL"

        assert change_pct is not None
        if change_pct >= 20.0:
            return "HIGH"
        if change_pct <= -20.0:
            return "LOW"
        return "NORMAL"

    @staticmethod
    def _classify_trend(
        first_half: float,
        second_half: float,
        trend_pct: float | None,
    ) -> str:
        """Classify trend using the two halves of the forecast horizon."""
        if first_half <= 1e-9:
            return "UP" if second_half > 1e-9 else "STABLE"

        assert trend_pct is not None
        if trend_pct >= 10.0:
            return "UP"
        if trend_pct <= -10.0:
            return "DOWN"
        return "STABLE"

    @staticmethod
    def _classify_volatility(forecast_cv: float | None) -> str:
        """Classify variability using coefficient of variation (std / mean)."""
        if forecast_cv is None:
            return "LOW"
        if forecast_cv >= 0.50:
            return "HIGH"
        if forecast_cv >= 0.20:
            return "MEDIUM"
        return "LOW"

    def compute_inventory_plan(
        self,
        item_id: str,
        forecast: List[float],
    ) -> InventoryPlan:
        """Compute stockout risk and reorder recommendation from the forecast."""
        return self.planner.compute_inventory_plan(item_id, forecast)

    def analyze_item(
        self,
        item_id: str,
        horizon_days: int | None = None,
    ) -> Tuple[DemandInsight, InventoryPlan]:
        """Run demand forecast and inventory planning for one item."""
        demand = self.forecast_demand(item_id, horizon_days=horizon_days)
        plan = self.compute_inventory_plan(item_id, demand.daily_forecast)
        return demand, plan
